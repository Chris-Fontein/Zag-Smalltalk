const std = @import("std");
const builtin = @import("builtin");
const Process = @import("process.zig");
pub const is_test = builtin.is_test;
pub const testRun = debugMode or show_trace;
pub const debugMode = builtin.mode == .Debug;
pub const native_endian = builtin.target.cpu.arch.endian();
pub const tailCall: std.builtin.CallModifier = if (show_error_stack) .never_inline else .always_tail;
pub fn trace(comptime format: anytype, values: anytype) void {
    if (show_trace) std.log.debug(format, values);
}
const options = @import("options");
pub const includeLLVM = options.includeLLVM;
pub const git_version = options.git_version;
pub const compile_date = options.compile_date;
pub const objectEncoding = options.objectEncoding;
pub const max_classes = options.maxClasses;
pub const singleSteppable = false; //options.singleSteppable;
// must be more than HeapObject.maxLength*8 so externally allocated
pub const process_total_size: usize = if (is_test or testRun) 2048 * 4 else 64 * 1024;

pub const debugging = false;
pub const logThreadExecution: ?fn (comptime []const u8, anytype) void = if (options.trace) std.log.debug else null;
const show_error_stack = debugging;
pub const show_trace = debugging or options.trace;

pub const immediateIntegers = switch (objectEncoding) {
    .zag, .nan, .spur, .zagSpur, .onlyInt, .taggedInt, .taggedPtr => true,
    else => false,
};
pub const immediateSymbols = switch (objectEncoding) {
    .zag, .nan, .zagSpur, .onlyInt, .onlyFloat => true,
    else => false,
};
pub const notZag = objectEncoding != .zag;
pub fn skipNotZag() !void {
    if (notZag) return error.SkipZigTest;
}
pub const skipForDebugging = error.SkipZigTest;
pub fn printConfig() void {
    std.debug.print(
        \\
        \\Config:
        \\  compile_date   = {s}
        \\  git_version    = {s}
        \\  cpu            = {s} ({}){s}
        \\  objectEncoding = {}
        \\  max_classes    = {}
        \\  stack/nursery  = {d}w/{d}w ({d}w){s}{s}{s}{s}
        \\
    , .{
        compile_date,
        git_version,
        builtin.target.cpu.model.name,
        builtin.target.cpu.arch,
        if (native_endian == .big) " big endian" else "",
        objectEncoding,
        max_classes,
        Process.process_stack_size,
        Process.process_nursery_size,
        process_total_size / 8,
        if (is_test) "\n  is test" else "",
        if (debugMode) "\n  is debugMode" else "",
        if (show_trace) "\n  trace enabled" else "",
        if (show_error_stack) "\n  error stack enabled" else "",
    });
}
comptime {
    @setEvalBranchQuota(100000);
}
test {
    printConfig();
}
