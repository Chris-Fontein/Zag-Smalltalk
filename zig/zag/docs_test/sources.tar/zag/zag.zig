//! Zag is a Smalltalk VM/runtime in Zig.
//!
//! This module is the public entry point for the core runtime and wires
//! together execution, heap, object encodings, primitives, and optional LLVM.
//!
//! ## Core Components
//!
//! - **Object encodings**: Multiple strategies for representing Smalltalk objects
//! - **Execution engine**: Bytecode interpreter with method dispatch
//! - **Heap management**: Object allocation and garbage collection
//! - **Primitives**: Built-in operations for core Smalltalk types
//! - **LLVM integration**: Optional JIT compilation support
//!
//! ## Usage
//!
//! ```zig
//! const zag = @import("zag");
//!
//! // Access core components
//! const Object = zag.Object;
//! const Process = zag.Process;
//! const Context = zag.Context;
//! ```

/// Build configuration options and feature toggles.
pub const config = @import("config.zig");
/// In-memory object representation utilities.
pub const InMemory = @import("object/inMemory.zig");

/// Object encoding and representation system.
pub const object = @import("object.zig");

/// The core Object type used throughout the VM.
pub const Object = object.Object;

/// Bytecode execution engine and method invocation.
pub const execute = @import("execute.zig");

/// Execution context management.
pub const Context = @import("context.zig");

/// Process object layout and stack management.
pub const Process = @import("process.zig");

/// Heap object allocation and format helpers.
pub const heap = @import("heap.zig");

/// Global memory arena management.
pub const globalArena = @import("globalArena.zig");

/// Symbol table and symbol management.
pub const symbol = @import("symbol.zig");

/// Control word definitions for bytecode.
pub const controlWords = @import("controlWords.zig");

/// Built-in primitive operations.
pub const primitives = @import("primitives.zig");

/// General utility functions and data structures.
pub const utilities = @import("utilities.zig");

/// LLVM integration (when enabled with -Dllvm=true).
pub const llvm = if (config.includeLLVM) @import("llvm-build-module") else null;

/// Threaded function implementations.
pub const threadedFn = @import("threadedFn.zig");

/// Performance statistics tracking.
pub const Stats = utilities.Stats;

/// Method dispatch tables and signature lookup.
pub const dispatch = @import("dispatch.zig");
pub fn untested() void {
    @import("std").debug.panic("Untested", .{});
}
